const urlInput=document.getElementById("url");
const getVideo=document.getElementById("getVideo");
const message=document.getElementById("message");
const video=document.getElementById("video");
const thumbnail=document.getElementById("thumbnail");
const title=document.getElementById("title");
let currentUrl="";

getVideo.addEventListener("click",async()=>{
    const url=urlInput.value.trim();
    if(!url)return showMessage("Please enter a YouTube URL.",true);
    currentUrl=url; getVideo.disabled=true; showMessage("Getting video information...",false);
    try{
        const response=await fetch("/api/info",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url})});
        const data=await response.json();
        if(!response.ok)throw new Error(data.error||"Request failed");
        title.textContent=data.title||"Video";
        if(data.thumbnail)thumbnail.src=data.thumbnail;
        video.classList.remove("hidden");
        showMessage("Video found.",false);
    }catch(error){showMessage(error.message,true)}
    finally{getVideo.disabled=false}
});

document.querySelectorAll(".format").forEach(button=>{
    button.addEventListener("click",async()=>{
        const format=button.dataset.format, quality=button.dataset.quality;
        if(!currentUrl)return;
        showMessage("Preparing download...",false); button.disabled=true;
        try{
            const response=await fetch("/api/download",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:currentUrl,format,quality})});
            if(!response.ok){const data=await response.json();throw new Error(data.error||"Download failed")}
            const blob=await response.blob(), downloadUrl=URL.createObjectURL(blob), a=document.createElement("a");
            a.href=downloadUrl;a.download=format==="mp3"?"audio.mp3":"video.mp4";document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(downloadUrl);
            showMessage("Download started.",false);
        }catch(error){showMessage(error.message,true)}
        finally{button.disabled=false}
    });
});

function showMessage(text,error){message.textContent=text;message.className=error?"error":"success"}