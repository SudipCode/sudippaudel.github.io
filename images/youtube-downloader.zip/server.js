const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/info", async (req, res) => {
    try {
        const { url } = req.body;

        if (!url) {
            return res.status(400).json({ error: "YouTube URL is required" });
        }

        if (!isYouTubeUrl(url)) {
            return res.status(400).json({ error: "Invalid YouTube URL" });
        }

        res.json({
            title: "Video information",
            available: true
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Unable to get video information" });
    }
});

app.post("/api/download", async (req, res) => {
    try {
        const { url, format, quality } = req.body;

        if (!url) {
            return res.status(400).json({ error: "YouTube URL is required" });
        }

        if (!isYouTubeUrl(url)) {
            return res.status(400).json({ error: "Invalid YouTube URL" });
        }

        if (!["mp4", "mp3"].includes(format)) {
            return res.status(400).json({ error: "Invalid format" });
        }

        console.log({ url, format, quality });

        res.status(501).json({
            error: "Download provider is not configured yet."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Download failed" });
    }
});

function isYouTubeUrl(value) {
    try {
        const url = new URL(value);
        return [
            "youtube.com",
            "www.youtube.com",
            "m.youtube.com",
            "youtu.be",
            "www.youtu.be"
        ].includes(url.hostname);
    } catch {
        return false;
    }
}

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});